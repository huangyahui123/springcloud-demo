package com.chinasofti.springcloud.feign;

import org.springframework.stereotype.Component;

@Component
public interface UserFeignClientWithFactory extends UserFeignClient {

}
