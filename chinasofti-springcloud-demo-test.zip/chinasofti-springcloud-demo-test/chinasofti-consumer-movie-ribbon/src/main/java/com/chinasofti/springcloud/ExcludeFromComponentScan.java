package com.chinasofti.springcloud;

public @interface ExcludeFromComponentScan {

}
