package com.chinasofti.springcloud.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chinasofti.springcloud.common.CommonResponse;
import com.chinasofti.springcloud.entity.User;
import com.chinasofti.springcloud.entity.UserVO;
import com.chinasofti.springcloud.repository.UserRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;

@RestController
@RequestMapping("/user")
public class UserController {
	
	public static ObjectMapper objectMapper = new ObjectMapper();
	
  @Autowired
  private UserRepository userRepository;

  @Autowired
  private EurekaClient eurekaClient;

  @Autowired
  private DiscoveryClient discoveryClient;
  
  @RequestMapping("/queryUserList")
  public CommonResponse<List<UserVO>> queryUserList() throws IOException{
	  CommonResponse<List<UserVO>> result = new CommonResponse<List<UserVO>>();
	  
	  //String jsonString = "[{\"id\":\"001\",\"username\":\"黄生\"},{\"id\":\"003\",\"username\":\"李小姐\"}]";
	  
	  String jsonString = "[{\"id\":\"001\",\"username\":\"黄生\"},{\"id\":\"003\",\"username\":\"李小姐\"}]";
	  //将json字符串， 转为对象
	  List<UserVO> data = objectMapper.readValue(jsonString, List.class);
	  
	  String js = objectMapper.writeValueAsString(data);
	  System.out.println(js);
	
	  result.setResult(data);
	  return result;
  }
  
  @RequestMapping("/queryUserById")
  public User queryUserById(@RequestParam Long id){
	  return this.userRepository.findOne(id);
  }
  
  @GetMapping("/simple/{id}")
  public User findById(@PathVariable Long id) {
    return this.userRepository.findOne(id);
  }

  @GetMapping("/eureka-instance")
  public String serviceUrl() {
    InstanceInfo instance = this.eurekaClient.getNextServerFromEureka("MICROSERVICE-PROVIDER-USER", false);
    return instance.getHomePageUrl();
  }

  @GetMapping("/instance-info")
  public ServiceInstance showInfo() {
    ServiceInstance localServiceInstance = this.discoveryClient.getLocalServiceInstance();
    return localServiceInstance;
  }

  @PostMapping("/user")
  public User postUser(@RequestBody User user) {
    return user;
  }

  // 该请求不会成功
  @GetMapping("/get-user")
  public User getUser(User user) {
    return user;
  }

  @GetMapping("list-all")
  public List<User> listAll() {
    ArrayList<User> list = Lists.newArrayList();
    User user = new User(1L, "zhangsan");
    User user2 = new User(2L, "zhangsan");
    User user3 = new User(3L, "zhangsan");
    list.add(user);
    list.add(user2);
    list.add(user3);
    return list;

  }
}
